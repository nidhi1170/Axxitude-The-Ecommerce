import React from 'react'

const DC3 = () => {
    return (
        <div className='DC3'>
            
        </div>
    )
}

export default DC3