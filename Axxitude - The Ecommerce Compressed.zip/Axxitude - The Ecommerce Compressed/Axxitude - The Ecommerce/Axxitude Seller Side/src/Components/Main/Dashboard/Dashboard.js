import React, { useEffect, useState } from 'react'
import './Dashboard.css'
import {getUserDataToLogin} from '../../Api'
import Profile from '../../Profile/Profile'
import SellerDataContainer from './SellerDataContainer'
import {Link, useHistory,Route, Switch} from 'react-router-dom'

function Dashboard() {
    const History = useHistory()
    const [sellerInfo,setSellerInfo] = useState({Fullname:'',BusinessName:'',BusinessType:'',StoreAddress:'',Email:''})
    const seller_account_email = localStorage.getItem("seller_account_email");
    useEffect(() => {
        const getDetails = async() =>{
            const sellerData = await getUserDataToLogin(seller_account_email)
            if(sellerData.data.length===0){
                History.push('/')
                return
            }
            setSellerInfo(sellerData.data[0])
        }
        getDetails()
    }, [seller_account_email,History])

    return (
        <div className='dashboard'>
            <div className='dashboard_navbar'>
                <h1> {sellerInfo.BusinessName } <p>powered by Axxitude</p></h1>
                <div className='dashboard_navbar_items_container'>
                    <div className='dashboard_navbar_item'><span>Account Management </span></div>
                    <Link to='/advertising'  className='dashboard_navbar_item'><div ><span>Advertising</span></div></Link>
                    <div className='dashboard_navbar_item'><span>More Services  </span></div>
                    <Link to='/profile' className='dashboard_navbar_item'><div><span>Your Profile </span></div></Link>
                </div>
            </div>
            <Switch>
                <Route path="/profile" exact component={Profile} />
                <Route path="/dashboard" exact component={SellerDataContainer} />
            </Switch>
           
            
        </div>
    )
}

export default Dashboard
