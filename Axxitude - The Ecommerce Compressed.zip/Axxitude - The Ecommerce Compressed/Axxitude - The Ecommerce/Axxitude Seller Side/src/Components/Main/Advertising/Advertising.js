import React from 'react';
import './Advertising.css'
import AdvertisingStatic from './AdvertisingStatic'
import AdvertisingDynamic from './AdvertisingDynamic'

const Advertising = () => {
    return (
        <div className="AdvertisingComponent">
           <AdvertisingStatic />
           <AdvertisingDynamic />
        </div>
    )
}

export default Advertising
