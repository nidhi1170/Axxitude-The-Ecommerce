import { combineReducers } from 'redux';

import sellerproducts_ from './SellerProducts';
import sellerdata from './SellerData';
import isLoggedIn from './isLoggedIn';

export const reducers =  combineReducers({ sellerproducts_,sellerdata,isLoggedIn })