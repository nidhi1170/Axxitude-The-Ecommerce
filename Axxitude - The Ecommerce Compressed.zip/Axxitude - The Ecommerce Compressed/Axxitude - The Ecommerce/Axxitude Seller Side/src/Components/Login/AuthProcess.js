import './AuthProcess.css';
import React from 'react'

function AuthProcess() {
    return (
        <div className='AuthProcess'>
            <div className='AuthProcess_Rotator'></div>
        </div>
    )
}

export default AuthProcess
