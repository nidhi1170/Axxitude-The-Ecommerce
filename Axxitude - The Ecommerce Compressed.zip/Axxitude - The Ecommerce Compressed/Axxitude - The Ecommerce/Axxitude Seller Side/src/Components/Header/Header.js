import React,{useEffect, useState} from 'react'
import logo from '../../Media/LOGO/logo.png'
import './Header.css'
import { Link } from 'react-router-dom'
import {useHistory} from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { CLEARPRODUCTS, LOGINAUTH, LOGOUT, LOGOUTAUTH } from '../Constants/Constants'
import { login_user } from '../Actions'
function Header() {
    useEffect(() => {
        if(localStorage.getItem('seller_account_email')!==null){
            dispatch(login_user(localStorage.getItem('seller_account_email')))
            dispatch({type:LOGINAUTH})

        }
    }, []) 
    const isLoggedAuth = useSelector(state=>state.isLoggedIn);
    const [menuClick,setMenuClick] = useState(false)
    const History = useHistory()
    const dispatch = useDispatch()

    const Logout = () =>{
        localStorage.setItem('seller_account_email',null)
        dispatch({type:LOGOUT})
        dispatch({type:LOGOUTAUTH})
        dispatch({type:CLEARPRODUCTS})
        History.push('/login')
    }
    return (
        <div className="header">
            <div className="logo_container">
                <div className="logo">
                    <Link to={isLoggedAuth? '/dashboard':'/'}><img src={logo} alt='AXXITUDE' /></Link>
                </div>
            </div>
            <div className="menubar"><i className={menuClick?"far fa-caret-square-up":"far fa-caret-square-down"} onClick={()=>setMenuClick(!menuClick)}></i></div>
            <div className={menuClick?'nav_buttons_container':'nav_buttons_container hide_navbuttons'}>
                {!isLoggedAuth && <Link to='/register' style={{textDecoration:"none"}}><div className="nav_button">Register For Seller's Account</div></Link>}
                <Link to='/contact'><div className="nav_button">Contact</div></Link>
                <Link to='/about'><div className="nav_button">About Axxitude's Seller Side</div></Link>
                {isLoggedAuth? 
                    <div className="nav_button" onClick={Logout}>Logout</div>:
                    <Link to='/login' style={{textDecoration:"none"}}><div className="nav_button">Login</div></Link>
                }
            </div>
        </div>
    )
}

export default Header
