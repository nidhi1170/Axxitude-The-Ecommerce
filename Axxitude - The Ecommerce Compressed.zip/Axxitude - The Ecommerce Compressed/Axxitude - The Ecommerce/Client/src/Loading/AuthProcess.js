import './AuthProcess.css';
import React, { useEffect, useState } from 'react'

function AuthProcess() {
    const [joke,setJoke] = useState({})
    useEffect(() => {
        fetch('https://official-joke-api.appspot.com/random_joke')
            .then(res=>res.json())
            .then((json)=>{
               setJoke(json)
            })
        .catch(err => {
            console.error(err);
        });
    },[])
    return (
        <div className='AuthProcess'>
            <div className='AuthProcess_Rotator'></div>
            <h3 style={{color:"black",textAlign:"center"}}>Here's some boring stuff while we load your data</h3>
            <div className='randomJoke'>
                <div className='setup'>{joke.setup}</div>
                <div className="punchline">{joke.punchline}</div>
            </div>
        </div>
    )
}

export default AuthProcess
